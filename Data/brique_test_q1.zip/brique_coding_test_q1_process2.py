import socket
import tkinter

#기본 영역
win = tkinter.Tk()
win.title('메세지를 받자!')

#프레임 영역
base_frm = tkinter.Frame(win)

# 메시지 라벨
textLabel = tkinter.Label(win)
textLabel.pack()


def closing_win():
    win.destroy()

win.protocol("WM_DELETE_WINDOW", closing_win)

HOST = ''
PORT = 20000
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)
conn, addr = s.accept()

def gettingMsg():
    while True:
        data = conn.recv(1024)
        if not data:
            break
        else:
            data = data.decode('utf-8','ignore')
            return data
    conn.close()

textLabel.configure(text=gettingMsg(),font='Helvetica -20',width=80, height=20)

win.mainloop()