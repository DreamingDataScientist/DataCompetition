import socket
import tkinter

#기본 영역
win = tkinter.Tk()
win.title('메세지를 보내자!')

#프레임 영역
base_frm = tkinter.Frame(win, width=600,height=200)
base_frm.pack(fill=None, expand=False)
base_frm.pack_propagate(0)

HOST = 'localhost'
PORT = 20000
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

def sendingMsg():
    data = 'Hello'
    data = bytes(data, "utf-8")
    s.send(data)

#send 버튼
button = tkinter.Button(master=base_frm, text='Send', command=sendingMsg, height=50, width=150)
button.pack()

def closing_win():
    s.close()
    win.destroy()

win.protocol("WM_DELETE_WINDOW", closing_win)
win.mainloop()
